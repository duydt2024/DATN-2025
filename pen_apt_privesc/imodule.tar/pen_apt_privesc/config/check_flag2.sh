#!/bin/bash
if grep -q "FLAG2_HISTORY" /home/devops/flag2.txt; then
    exit 0
else
    exit 1
fi
