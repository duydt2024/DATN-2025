#!/bin/bash
diff /root/final_flag7.txt /home/intern/root_proof.txt >/dev/null 2>&1
exit $?

