#!/bin/bash
if grep -q "FLAG6_CAPABILITY" /var/log/privesc/cap_flag 2>/dev/null; then
    exit 0
else
    exit 1
fi
