#!/bin/bash
diff /root/flag3.txt /home/devops/flag3.txt >/dev/null 2>&1
exit $?
