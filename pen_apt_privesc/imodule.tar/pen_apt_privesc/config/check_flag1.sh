#!/bin/bash
if grep -q "FLAG1_ENUM" /home/intern/flag1.txt; then
    exit 0
else
    exit 1
fi
