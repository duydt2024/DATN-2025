#!/bin/bash
if grep -q "FLAG4_PATH_HIJACK" /var/log/privesc/flag4_proof 2>/dev/null; then
    exit 0
else
    exit 1
fi
