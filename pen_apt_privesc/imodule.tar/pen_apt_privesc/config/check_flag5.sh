#!/bin/bash
diff /root/flag5.txt /home/backup/flag5.txt >/dev/null 2>&1
exit $?
