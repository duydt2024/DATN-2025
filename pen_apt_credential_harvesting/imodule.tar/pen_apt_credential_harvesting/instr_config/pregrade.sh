#!/bin/bash
: <<'END'
This software was created by United States Government employees at 
The Center for Cybersecurity and Cyber Operations (C3O) 
at the Naval Postgraduate School NPS.  Please note that within the 
United States, copyright protection is not available for any works 
created  by United States Government employees, pursuant to Title 17 
United States Code Section 105.   This software is in the public 
domain and is not subject to copyright. 
END
#
# Script to run prior to grading a student's lab.
# It will:
#  - Locate the client and mspserver container filesystems inside the
#    submitted .lab archive.
#  - Copy client:/home/ubuntu/flag.txt and mspserver:/home/ubuntu/secret.txt
#    into a temporary directory.
#  - If both exist, diff the two files.
#      + If identical  -> create /home/ubuntu/ssh_ok (mode 711) in the
#                        mspserver filesystem.
#      + If different  -> ensure ssh_ok does not exist.
#
# Grading then checks:
#   ssh_secret = mspserver:/home/ubuntu/ssh_ok : CONTAINS : OK
#

homedir=$1    # e.g., /home/instructor
destdir=$2    # e.g., B21DCAT107.pen_apt_credential_harvesting/pen_apt_credential_harvesting.client.student

student_rel_dir="$(dirname "$destdir")"
student_dir="$homedir/$student_rel_dir"

CLIENT_DIR="$student_dir/pen_apt_credential_harvesting.client.student"
MSPSERVER_DIR="$student_dir/pen_apt_credential_harvesting.mspserver.student"

mkdir -p "$homedir/tmp"

if [ -f "$CLIENT_DIR/home/ubuntu/flag.txt" ]; then
    cp "$CLIENT_DIR/home/ubuntu/flag.txt" "$homedir/tmp/client_flag.txt"
fi

if [ -f "$MSPSERVER_DIR/home/ubuntu/secret.txt" ]; then
    cp "$MSPSERVER_DIR/home/ubuntu/secret.txt" "$homedir/tmp/secret.txt"
fi

if [ -f "$homedir/tmp/client_flag.txt" ] && [ -f "$homedir/tmp/secret.txt" ]; then
    if diff -q "$homedir/tmp/client_flag.txt" "$homedir/tmp/secret.txt" >/dev/null 2>&1; then
        mkdir -p "$MSPSERVER_DIR/home/ubuntu"
        echo OK > "$MSPSERVER_DIR/home/ubuntu/ssh_ok"
        chmod 711 "$MSPSERVER_DIR/home/ubuntu/ssh_ok"
    else
        rm -f "$MSPSERVER_DIR/home/ubuntu/ssh_ok"
    fi
fi

#
#  Add other processing below (if needed).
#

